import cv2
import pandas as pd
from ultralytics import YOLO
import torch

model = YOLO('best.pt')

def RGB(event, x, y, flags, param):
    if event == cv2.EVENT_MOUSEMOVE:
        colorsBGR = [x, y]
        print(colorsBGR)

cv2.namedWindow('RGB')
cv2.setMouseCallback('RGB', RGB)

cap = cv2.VideoCapture(0)
my_file = open("coco.txt", "r")
data = my_file.read()
class_list = data.split("\n")
count = 0

# Define class labels for bottles and cans
ipomoeaindica_label = "ipomoeaindica"
amaranthustuberculatus_label = "amaranthustuberculatus"


while True:
    ret, frame = cap.read()
    count += 1
    if count % 3 != 0:
        continue

    frame = cv2.resize(frame, (1020, 500))

    results = model.predict(frame, conf=0.7)
    xyxy_boxes = results[0].boxes.xyxy
    confidences = results[0].boxes.conf
    class_ids = results[0].boxes.cls

    detected = False  # Flag to check if any object was detected

    for i in range(len(xyxy_boxes)):
        x1, y1, x2, y2 = map(int, xyxy_boxes[i][:4])
        class_id = int(class_ids[i])
        label = class_list[class_id]
        confidence = float(confidences[i])

        if confidence > 0.7:
            detected = True

            if label == ipomoeaindica_label:
                print("amaranthustuberculatus is detected")
                cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
                cv2.putText(frame, f'{label}: {confidence:.2f}', (x1, y1), cv2.FONT_HERSHEY_COMPLEX, 0.5, (255, 0, 0), 1)

            elif label == amaranthustuberculatus_label:
                print("ipomoeaindica is detected")
                cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
                cv2.putText(frame, f'{label}: {confidence:.2f}', (x1, y1), cv2.FONT_HERSHEY_COMPLEX, 0.5, (255, 0, 0), 1)

    if not detected:
        print("No weed plant is detected")

    cv2.imshow("RGB", frame)

    if cv2.waitKey(1) & 0xFF == 27:
        break

cap.release()
cv2.destroyAllWindows()
